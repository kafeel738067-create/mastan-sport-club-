package com.mastan.sportclub.controller;
import com.mastan.sportclub.model.User; import com.mastan.sportclub.repository.UserRepository; import com.mastan.sportclub.security.JwtService;
import jakarta.validation.Valid; import jakarta.validation.constraints.*; import org.springframework.http.*; import org.springframework.security.crypto.password.PasswordEncoder; import org.springframework.web.bind.annotation.*; import java.util.Map;
@RestController @RequestMapping("/api/auth")
public class AuthController {
  private final UserRepository users; private final PasswordEncoder enc; private final JwtService jwt;
  public AuthController(UserRepository u,PasswordEncoder e,JwtService j){users=u;enc=e;jwt=j;}
  public record RegisterReq(@NotBlank String name,@Email @NotBlank String email,@NotBlank String phone,@Size(min=6) String password){}
  public record LoginReq(@Email @NotBlank String email,@NotBlank String password){}
  @PostMapping("/register") public ResponseEntity<?> register(@Valid @RequestBody RegisterReq r){
    if(users.findByEmailIgnoreCase(r.email()).isPresent()) return ResponseEntity.status(HttpStatus.CONFLICT).body(Map.of("message","Email already registered"));
    User u=new User();u.setName(r.name());u.setEmail(r.email().trim().toLowerCase());u.setPhone(r.phone());u.setPassword(enc.encode(r.password()));u.setRole("MEMBER");users.save(u);
    return ResponseEntity.ok(Map.of("message","Registration successful"));
  }
  @PostMapping("/login") public ResponseEntity<?> login(@Valid @RequestBody LoginReq r){return doLogin(r,false);}
  @PostMapping("/admin/login") public ResponseEntity<?> adminLogin(@Valid @RequestBody LoginReq r){return doLogin(r,true);}
  private ResponseEntity<?> doLogin(LoginReq r,boolean admin){
    var u=users.findByEmailIgnoreCase(r.email()).orElse(null);
    if(u==null || !enc.matches(r.password(),u.getPassword()) || (admin && !"ADMIN".equals(u.getRole()))) return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("message","Invalid login"));
    return ResponseEntity.ok(Map.of("token",jwt.generate(u.getEmail(),u.getRole()),"role",u.getRole(),"name",u.getName(),"email",u.getEmail()));
  }
}
