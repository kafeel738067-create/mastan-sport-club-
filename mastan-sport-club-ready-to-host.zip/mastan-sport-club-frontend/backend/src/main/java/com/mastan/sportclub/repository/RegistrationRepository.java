package com.mastan.sportclub.repository;
import com.mastan.sportclub.model.EventRegistration;
import org.springframework.data.jpa.repository.JpaRepository;
public interface RegistrationRepository extends JpaRepository<EventRegistration,Long>{ long countByEventId(Long eventId); }
