package com.mastan.sportclub.controller;
import org.springframework.beans.factory.annotation.Value; import org.springframework.core.io.*; import org.springframework.http.*; import org.springframework.web.bind.annotation.*; import java.nio.file.*;
@RestController
public class UploadController {
  private final Path dir;
  public UploadController(@Value("${app.upload-dir}") String d){dir=Paths.get(d).toAbsolutePath().normalize();}
  @GetMapping("/uploads/{filename:.+}") public ResponseEntity<Resource> get(@PathVariable String filename)throws Exception{
    Path p=dir.resolve(filename).normalize(); if(!p.startsWith(dir)||!Files.exists(p))return ResponseEntity.notFound().build();
    Resource r=new FileSystemResource(p); MediaType type=MediaType.parseMediaType(Files.probeContentType(p)==null?"application/octet-stream":Files.probeContentType(p));
    return ResponseEntity.ok().contentType(type).body(r);
  }
}
