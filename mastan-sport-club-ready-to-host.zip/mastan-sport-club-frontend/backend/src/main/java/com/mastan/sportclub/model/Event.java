package com.mastan.sportclub.model;
import jakarta.persistence.*;
@Entity @Table(name="events")
public class Event {
  @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
  @Column(nullable=false) private String name;
  @Column(nullable=false) private String sport;
  @Column(nullable=false) private String date;
  @Column(nullable=false) private String venue;
  private String prize;
  @Column(length=2000) private String description;
  public Event() {}
  public Long getId(){return id;} public String getName(){return name;} public void setName(String v){name=v;}
  public String getSport(){return sport;} public void setSport(String v){sport=v;}
  public String getDate(){return date;} public void setDate(String v){date=v;}
  public String getVenue(){return venue;} public void setVenue(String v){venue=v;}
  public String getPrize(){return prize;} public void setPrize(String v){prize=v;}
  public String getDescription(){return description;} public void setDescription(String v){description=v;}
}
