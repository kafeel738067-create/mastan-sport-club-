package com.mastan.sportclub.config;
import com.mastan.sportclub.model.*; import com.mastan.sportclub.repository.*;
import org.springframework.beans.factory.annotation.Value; import org.springframework.boot.CommandLineRunner; import org.springframework.context.annotation.*; import org.springframework.security.crypto.password.PasswordEncoder;
@Configuration
public class DataInitializer {
  @Bean CommandLineRunner seed(UserRepository users,EventRepository events,PasswordEncoder enc,
      @Value("${app.admin.email}") String email,@Value("${app.admin.password}") String password){
    return args -> {
      if(users.findByEmailIgnoreCase(email).isEmpty()){User u=new User();u.setName("MSC Admin");u.setEmail(email);u.setPhone("");u.setPassword(enc.encode(password));u.setRole("ADMIN");users.save(u);}
      if(events.count()==0){
        Event a=new Event();a.setName("Mastan Cricket Tournament");a.setSport("Cricket");a.setDate("2026-10-05");a.setVenue("Mastan Sports Ground");a.setPrize("₹5,100");a.setDescription("Open cricket tournament for local teams.");events.save(a);
        Event b=new Event();b.setName("Football Championship");b.setSport("Football");b.setDate("2026-10-20");b.setVenue("Club Football Ground");b.setPrize("₹3,100");b.setDescription("Competitive football championship.");events.save(b);
        Event c=new Event();c.setName("Sports Day");c.setSport("Multi Sport");c.setDate("2026-11-01");c.setVenue("Mastan Sport Club");c.setPrize("Medals & Cups");c.setDescription("A full day of sports and community activities.");events.save(c);
      }
    };
  }
}
