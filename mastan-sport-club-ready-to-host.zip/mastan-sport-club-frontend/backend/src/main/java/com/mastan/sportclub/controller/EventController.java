package com.mastan.sportclub.controller;
import com.mastan.sportclub.model.*; import com.mastan.sportclub.repository.*; import jakarta.validation.Valid; import jakarta.validation.constraints.*; import org.springframework.http.*; import org.springframework.web.bind.annotation.*; import java.util.*;
@RestController @RequestMapping("/api")
public class EventController {
  private final EventRepository events; private final RegistrationRepository regs;
  public EventController(EventRepository e,RegistrationRepository r){events=e;regs=r;}
  @GetMapping("/events") public List<Event> all(){return events.findAll();}
  @GetMapping("/events/{id}") public ResponseEntity<Event> one(@PathVariable Long id){return events.findById(id).map(ResponseEntity::ok).orElseGet(()->ResponseEntity.notFound().build());}
  @PostMapping("/events") public Event add(@Valid @RequestBody EventRequest r){Event e=new Event();copy(e,r);return events.save(e);}
  @DeleteMapping("/events/{id}") public ResponseEntity<?> del(@PathVariable Long id){if(!events.existsById(id))return ResponseEntity.notFound().build();events.deleteById(id);return ResponseEntity.noContent().build();}
  @PostMapping("/events/{id}/registrations") public ResponseEntity<?> register(@PathVariable Long id,@Valid @RequestBody RegistrationRequest r){
    Event e=events.findById(id).orElse(null); if(e==null)return ResponseEntity.notFound().build();
    EventRegistration x=new EventRegistration();x.setEvent(e);x.setName(r.name());x.setEmail(r.email());x.setPhone(r.phone());x.setTeam(r.team());regs.save(x);
    return ResponseEntity.ok(Map.of("message","Event registration submitted!"));
  }
  @GetMapping("/admin/registrations") public List<EventRegistration> registrations(){return regs.findAll();}
  @GetMapping("/admin/stats") public Map<String,Object> stats(PhotoRepository photos){return Map.of("events",events.count(),"photos",photos.count(),"registrations",regs.count());}
  public record EventRequest(@NotBlank String name,@NotBlank String sport,@NotBlank String date,@NotBlank String venue,String prize,String description){}
  public record RegistrationRequest(@NotBlank String name,@Email @NotBlank String email,@NotBlank String phone,String team){}
  private void copy(Event e,EventRequest r){e.setName(r.name());e.setSport(r.sport());e.setDate(r.date());e.setVenue(r.venue());e.setPrize(r.prize());e.setDescription(r.description());}
}
