package com.mastan.sportclub.repository;
import com.mastan.sportclub.model.Photo;
import org.springframework.data.jpa.repository.JpaRepository;
public interface PhotoRepository extends JpaRepository<Photo,Long>{}
