package com.mastan.sportclub.repository;
import com.mastan.sportclub.model.Event;
import org.springframework.data.jpa.repository.JpaRepository;
public interface EventRepository extends JpaRepository<Event,Long>{}
