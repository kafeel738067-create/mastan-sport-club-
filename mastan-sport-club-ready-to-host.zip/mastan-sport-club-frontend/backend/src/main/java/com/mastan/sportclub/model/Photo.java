package com.mastan.sportclub.model;
import jakarta.persistence.*;
@Entity @Table(name="photos")
public class Photo {
  @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
  @Column(nullable=false) private String filename;
  @Column(nullable=false) private String url;
  public Photo() {} public Photo(String f,String u){filename=f;url=u;}
  public Long getId(){return id;} public String getFilename(){return filename;} public String getUrl(){return url;}
}
