package com.mastan.sportclub.config;
import com.mastan.sportclub.security.JwtFilter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.*;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.*;
import java.util.*;
@Configuration
public class SecurityConfig {
  @Bean PasswordEncoder passwordEncoder(){return new BCryptPasswordEncoder();}
  @Bean SecurityFilterChain security(HttpSecurity http,JwtFilter jwt)throws Exception{
    http.csrf(c->c.disable()).cors(c->{}).sessionManagement(s->s.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
      .authorizeHttpRequests(a->a
        .requestMatchers("/api/auth/**","/uploads/**","/h2-console/**").permitAll()
        .requestMatchers(HttpMethod.GET,"/api/events","/api/events/**","/api/photos").permitAll()
        .requestMatchers(HttpMethod.POST,"/api/events/*/registrations").permitAll()
        .requestMatchers(HttpMethod.POST,"/api/auth/**").permitAll()
        .requestMatchers("/api/admin/**","/api/photos/**").hasRole("ADMIN")
        .requestMatchers(HttpMethod.POST,"/api/events").hasRole("ADMIN")
        .requestMatchers(HttpMethod.DELETE,"/api/events/**").hasRole("ADMIN")
        .anyRequest().authenticated())
      .addFilterBefore(jwt,UsernamePasswordAuthenticationFilter.class).headers(h->h.frameOptions(f->f.disable()));
    return http.build();
  }
  @Bean CorsConfigurationSource cors(@Value("${app.cors.allowed-origins:*}") String origins){
    CorsConfiguration c=new CorsConfiguration(); c.setAllowedOriginPatterns(List.of(origins.split(",")));
    c.setAllowedMethods(List.of("GET","POST","DELETE","PUT","OPTIONS")); c.setAllowedHeaders(List.of("*")); c.setAllowCredentials(false);
    UrlBasedCorsConfigurationSource s=new UrlBasedCorsConfigurationSource(); s.registerCorsConfiguration("/**",c); return s;
  }
}
