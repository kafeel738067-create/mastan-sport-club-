package com.mastan.sportclub.controller;
import com.mastan.sportclub.model.Photo; import com.mastan.sportclub.repository.PhotoRepository;
import org.springframework.beans.factory.annotation.Value; import org.springframework.http.*; import org.springframework.util.StringUtils; import org.springframework.web.bind.annotation.*; import org.springframework.web.multipart.MultipartFile;
import java.nio.file.*; import java.util.*; import java.util.stream.*;
@RestController @RequestMapping("/api/photos")
public class PhotoController {
  private final PhotoRepository repo; private final Path dir;
  public PhotoController(PhotoRepository r,@Value("${app.upload-dir}") String upload){repo=r;dir=Paths.get(upload).toAbsolutePath().normalize();try{Files.createDirectories(dir);}catch(Exception e){throw new RuntimeException(e);}}
  @GetMapping public List<Photo> all(){return repo.findAll();}
  @PostMapping(consumes=MediaType.MULTIPART_FORM_DATA_VALUE) public List<Photo> upload(@RequestParam("files") MultipartFile[] files)throws Exception{
    List<Photo> out=new ArrayList<>();
    for(MultipartFile f:files){if(f.isEmpty()||!Objects.requireNonNullElse(f.getContentType(),"").startsWith("image/"))continue;
      String name=UUID.randomUUID()+"-"+StringUtils.cleanPath(Objects.requireNonNull(f.getOriginalFilename()));
      Files.copy(f.getInputStream(),dir.resolve(name),StandardCopyOption.REPLACE_EXISTING);
      out.add(repo.save(new Photo(name,"/uploads/"+name)));
    } return out;
  }
  @DeleteMapping("/{id}") public ResponseEntity<?> del(@PathVariable Long id)throws Exception{
    var p=repo.findById(id).orElse(null);if(p==null)return ResponseEntity.notFound().build();
    Files.deleteIfExists(dir.resolve(p.getFilename()));repo.delete(p);return ResponseEntity.noContent().build();
  }
  @GetMapping("/files/{filename:.+}") public ResponseEntity<byte[]> file(@PathVariable String filename)throws Exception{
    Path p=dir.resolve(filename).normalize();if(!p.startsWith(dir)||!Files.exists(p))return ResponseEntity.notFound().build();
    return ResponseEntity.ok().contentType(MediaType.parseMediaType(Optional.ofNullable(Files.probeContentType(p)).orElse("application/octet-stream"))).body(Files.readAllBytes(p));
  }
}
