package com.mastan.sportclub;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class MastanSportClubApplication {
  public static void main(String[] args) { SpringApplication.run(MastanSportClubApplication.class, args); }
}
