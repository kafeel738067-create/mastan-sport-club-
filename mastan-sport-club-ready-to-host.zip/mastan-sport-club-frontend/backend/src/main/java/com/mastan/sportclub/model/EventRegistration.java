package com.mastan.sportclub.model;
import jakarta.persistence.*;
@Entity @Table(name="event_registrations")
public class EventRegistration {
  @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
  @ManyToOne(optional=false) private Event event;
  @Column(nullable=false) private String name;
  @Column(nullable=false) private String email;
  @Column(nullable=false) private String phone;
  private String team;
  public EventRegistration() {}
  public Long getId(){return id;} public Event getEvent(){return event;} public void setEvent(Event v){event=v;}
  public String getName(){return name;} public void setName(String v){name=v;}
  public String getEmail(){return email;} public void setEmail(String v){email=v;}
  public String getPhone(){return phone;} public void setPhone(String v){phone=v;}
  public String getTeam(){return team;} public void setTeam(String v){team=v;}
}
