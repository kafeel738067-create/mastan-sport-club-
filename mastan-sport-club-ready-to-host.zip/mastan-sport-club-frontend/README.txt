MASTAN SPORT CLUB - FRONTEND + SPRING BOOT BACKEND

This project now uses a real Spring Boot REST API instead of browser localStorage.

FOLDERS
- Frontend files: index.html, events.html, register.html, login.html, admin-login.html, admin.html, event-register.html
- config.js: frontend API URL (change this after hosting the backend)
- script.js: API-connected frontend logic
- backend/: Spring Boot API + H2 database + optional PostgreSQL support

LOCAL RUN
1. Install Java 17+ and Maven.
2. Open terminal in backend/.
3. Run:
   mvn spring-boot:run
4. API runs at http://localhost:8080
5. Open the frontend with VS Code Live Server.
6. config.js already points to http://localhost:8080/api

DEFAULT ADMIN
Email: kafeelahmad1314@gmail.com
Password: Kaf@12345
For production hosting, set ADMIN_PASSWORD to a strong secret and change it.

API FEATURES
- Member registration and login
- JWT authentication
- Admin login
- Events stored in database
- Event registrations stored in database
- Admin add/delete events
- Admin upload/delete photos
- Admin statistics
- CORS for frontend hosting

DATABASE
Default: H2 file database at backend/data/mastan.
For PostgreSQL hosting, set:
DB_URL=jdbc:postgresql://HOST:PORT/DATABASE
DB_USERNAME=...
DB_PASSWORD=...

IMPORTANT FOR HOSTING
1. Deploy backend first.
2. Copy the backend public URL.
3. Edit config.js:
   window.MSC_API_BASE='https://YOUR-BACKEND-URL/api';
4. Deploy the frontend.
5. If frontend and backend are on different domains, keep CORS_ALLOWED_ORIGINS configured. For better security, replace "*" with your exact frontend URL.

RENDER
The included render.yaml/Dockerfile can be used as a starting point for Render.
Build locally if needed:
cd backend
mvn clean package
The generated JAR is target/mastan-sport-club-backend-1.0.0.jar

SECURITY
- Passwords are BCrypt hashed.
- JWT tokens are used for authenticated admin/member sessions.
- Do not put production passwords or JWT secrets inside frontend JavaScript.
- Uploaded files are stored on the backend filesystem. On hosting platforms with ephemeral disks, use persistent storage or object storage for production images.
