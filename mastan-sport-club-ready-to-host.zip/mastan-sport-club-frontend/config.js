window.MSC_API_BASE='http://localhost:8080/api';
