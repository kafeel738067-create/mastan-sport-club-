const API_BASE=(localStorage.getItem('msc_api_base')||window.MSC_API_BASE||'http://localhost:8080/api').replace(/\/$/,'');
const API_ORIGIN=API_BASE.replace(/\/api\/?$/,'');
const token=()=>localStorage.getItem('msc_token');
const headers=(json=true)=>{const h={};if(json)h['Content-Type']='application/json';if(token())h.Authorization=`Bearer ${token()}`;return h};
const api=async(path,opt={})=>{
  const isForm=opt.body instanceof FormData;
  const baseHeaders=isForm?{}:headers(opt.body!==undefined);
  const r=await fetch(API_BASE+path,{...opt,headers:{...baseHeaders,...(opt.headers||{}),...(token()?{Authorization:`Bearer ${token()}`}:{})}});
  const text=await r.text(); let data={}; try{data=text?JSON.parse(text):{}}catch{data={message:text}};
  if(!r.ok) throw new Error(data.message||`Request failed (${r.status})`);
  return data;
};
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
const date=s=>s?new Date(s+'T00:00:00').toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'}):'TBA';
const messageEl=()=>document.getElementById('message');
const showMessage=(text,ok=false)=>{const m=messageEl();if(m){m.textContent=text;m.style.color=ok?'#159447':'#e63946'}};
function toggleMenu(){document.getElementById('nav')?.classList.toggle('open')}
function card(e){return `<article class="eventcard"><span class="eyebrow">${esc(e.sport)}</span><h3>${esc(e.name)}</h3><span class="pill">📅 ${date(e.date)}</span><span class="pill">📍 ${esc(e.venue)}</span><p>${esc(e.description)}</p><b>Prize: ${esc(e.prize||'TBA')}</b><br><a class="btn primary" href="event-register.html?id=${e.id}">Register Now</a></article>`}
async function render(){
  const a=document.getElementById('eventsList'),h=document.getElementById('homeEvents');
  try{
    const ev=await api('/events');
    if(a)a.innerHTML=ev.map(card).join('')||'<p>No events available.</p>';
    if(h)h.innerHTML=ev.slice(0,3).map(card).join('')||'<p>No upcoming events.</p>';
  }catch(e){if(a)a.innerHTML=`<p>Could not load events. ${esc(e.message)}</p>`;if(h)h.innerHTML='';}
  const g=document.getElementById('gallery');
  if(g)try{
    const p=await api('/photos');
    const d=['https://images.unsplash.com/photo-1461896836934-ffe607ba8211?auto=format&fit=crop&w=900&q=80','https://images.unsplash.com/photo-1579952363873-27f3bade9f55?auto=format&fit=crop&w=900&q=80','https://images.unsplash.com/photo-1518604666860-9ed391f76460?auto=format&fit=crop&w=900&q=80','https://images.unsplash.com/photo-1552674605-db6ffd4facb5?auto=format&fit=crop&w=900&q=80'];
    const urls=p.length?p.map(x=>API_ORIGIN+x.url):d;
    g.innerHTML=urls.map(x=>`<div><img src="${esc(x)}" alt="Club photo"></div>`).join('');
  }catch(e){g.innerHTML='';}
}
function saveAuth(data,admin=false){localStorage.setItem('msc_token',data.token);localStorage.setItem('msc_user',JSON.stringify({name:data.name,email:data.email,role:data.role}));if(admin)localStorage.setItem('msc_admin','true')}
async function formHandlers(){
  const f=document.getElementById('registerForm');
  if(f)f.onsubmit=async e=>{e.preventDefault();try{await api('/auth/register',{method:'POST',body:JSON.stringify({name:f.querySelector('#name').value,email:f.querySelector('#email').value,phone:f.querySelector('#phone').value,password:f.querySelector('#password').value})});showMessage('Registration successful!',true);setTimeout(()=>location.href='login.html',700)}catch(x){showMessage(x.message)}};
  const l=document.getElementById('loginForm');
  if(l)l.onsubmit=async e=>{e.preventDefault();try{const d=await api('/auth/login',{method:'POST',body:JSON.stringify({email:l.querySelector('#email').value,password:l.querySelector('#password').value})});saveAuth(d);showMessage('Login successful!',true);setTimeout(()=>location.href='index.html',500)}catch(x){showMessage(x.message)}};
  const al=document.getElementById('adminLoginForm');
  if(al)al.onsubmit=async e=>{e.preventDefault();try{const d=await api('/auth/admin/login',{method:'POST',body:JSON.stringify({email:al.querySelector('#email').value,password:al.querySelector('#password').value})});saveAuth(d,true);location.href='admin.html'}catch(x){showMessage(x.message)}};
  const ef=document.getElementById('eventForm');
  if(ef)try{
    const id=new URLSearchParams(location.search).get('id'),ev=await api('/events/'+id);
    if(ev)document.getElementById('eventInfo').textContent=`Register for: ${ev.name} • ${date(ev.date)}`;
    ef.onsubmit=async e=>{e.preventDefault();try{await api(`/events/${id}/registrations`,{method:'POST',body:JSON.stringify({name:ef.querySelector('#name').value,email:ef.querySelector('#email').value,phone:ef.querySelector('#phone').value,team:ef.querySelector('#team').value})});showMessage('Event registration submitted!',true);ef.reset()}catch(x){showMessage(x.message)}};
  }catch(x){document.getElementById('eventInfo').textContent='Event not found.'}
}
async function initAdmin(){
  const f=document.getElementById('eventAdminForm');if(!f)return;
  if(!token()||localStorage.getItem('msc_admin')!=='true'){location.href='admin-login.html';return}
  const refresh=async()=>{
    try{
      const [ev,p,st]=await Promise.all([api('/events'),api('/photos'),api('/admin/stats')]);
      document.getElementById('eventCount').textContent=st.events;document.getElementById('photoCount').textContent=st.photos;document.getElementById('regCount').textContent=st.registrations;
      document.getElementById('adminEvents').innerHTML=ev.map(e=>`<div class="adminEvent"><div><b>${esc(e.name)}</b><div>${date(e.date)} • ${esc(e.venue)}</div></div><button class="btn primary" onclick="deleteEvent(${e.id})">Delete</button></div>`).join('')||'<p>No events.</p>';
      document.getElementById('adminGallery').innerHTML=p.map(x=>`<div class="adminPhoto"><img src="${esc(API_ORIGIN+x.url)}"><button class="delete" onclick="deletePhoto(${x.id})">×</button></div>`).join('')||'<p>No uploaded photos.</p>';
    }catch(x){showMessage(x.message)}
  };
  await refresh();
  f.onsubmit=async e=>{e.preventDefault();try{await api('/events',{method:'POST',body:JSON.stringify({name:eventName.value,sport:sport.value,date:date.value,venue:venue.value,prize:prize.value,description:description.value})});e.target.reset();await refresh();render()}catch(x){showMessage(x.message)}};
  document.getElementById('photoInput').onchange=async e=>{
    try{const fd=new FormData();[...e.target.files].forEach(x=>fd.append('files',x));await api('/photos',{method:'POST',body:fd,headers:{}});e.target.value='';await refresh();render()}catch(x){showMessage(x.message)}
  };
}
async function deleteEvent(id){try{await api('/events/'+id,{method:'DELETE'});await initAdmin();render()}catch(x){showMessage(x.message)}}
async function deletePhoto(id){try{await api('/photos/'+id,{method:'DELETE'});await initAdmin();render()}catch(x){showMessage(x.message)}}
function logout(){localStorage.removeItem('msc_token');localStorage.removeItem('msc_user');localStorage.removeItem('msc_admin');location.href='index.html'}
document.addEventListener('DOMContentLoaded',()=>{render();formHandlers();initAdmin()});
